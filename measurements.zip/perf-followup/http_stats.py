from pathlib import Path
import collections, csv, json, math, statistics, sys
from stats import t95
root=Path(__file__).resolve().parent
def compare(f):
    blocks=collections.defaultdict(dict)
    for ln in f.read_text().splitlines():
        row=json.loads(ln);blocks[row['host_pair']][row['side']]=row
    assert all(len(v)==2 for v in blocks.values())
    for metric in ('rps','p95_ms','cpu_us_per_req','peak_working_set_bytes','private_bytes'):
        left=[v['off'][metric] for v in blocks.values()];right=[v['on'][metric] for v in blocks.values()]
        logs=[math.log(x/y if metric=='rps' else y/x) for x,y in zip(left,right)]
        m=statistics.mean(logs);width=t95[len(logs)-1]*statistics.stdev(logs)/math.sqrt(len(logs))
        yield dict(scheme=f.name,metric=metric,independent_hosts=len(logs),baseline_median=statistics.median(left),candidate_median=statistics.median(right),paired_overhead=100*math.expm1(m),low95=100*math.expm1(m-width),high95=100*math.expm1(m+width))
if __name__=='__main__':
    rows=[r for f in sorted(root.glob('httpfollowup-*.jsonl')) if 'delivery' not in f.name for r in compare(f)]
    if rows:
        w=csv.DictWriter(sys.stdout,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
