from pathlib import Path
import json,sys,subprocess
HERE=Path(__file__).resolve().parent
outdir=HERE/'supplement-Mocker';outdir.mkdir(exist_ok=True)
for mode in ('serial','overlap'):
    args=[sys.executable,str(HERE/'native_receipts.py'),'default']
    if mode=='overlap':args.append('--overlap')
    raw=json.loads(subprocess.check_output(args,encoding='utf8'))
    keys=('failed','elapsed','exit','start','terminal','ok')
    rows=[{k:r[k] for k in keys} for r in raw]
    assert len(rows)==6 and all((r['exit']!=0)==r['failed'] for r in rows)
    (outdir/('healthy-'+mode+'-delivery.json')).write_text(json.dumps(rows,indent=2))
    print(mode,sum(r['ok'] for r in rows),'/',len(rows),'complete matched receipts',flush=True)

