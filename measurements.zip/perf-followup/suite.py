"""Serial measurement batches. A failed dependency stops the batch and leaves its evidence on disk."""
from pathlib import Path
import os, subprocess, sys
root=Path(__file__).resolve().parent
product,stage=sys.argv[1:]
if product=='Runner' and stage=='primary':
    jobs=[('healthy',20,'runner-primary','base-off head-on prior-on head-off')]
elif product=='Runner' and stage=='controls':
    jobs=[(mode,4,'runner-'+mode,'base-off head-off head-on') for mode in ('slow','unreachable','disabled')]
    jobs += [('healthy',8,'runner-aa','head-off control-off')]
elif product=='Runner' and stage=='incremental':
    jobs=[('healthy',60,'runner-incremental','head-on head-off base-off')]
elif product=='Mocker' and stage=='primary':
    jobs=[(mode,n,'mocker-'+mode,'base-off prior-on head-off head-on') for mode,n in [('healthy',16),('slow',8),('unreachable',6),('disabled',4)]]
elif product=='Mocker' and stage=='failure':
    jobs=[(mode,4,'mocker-failure-'+mode,'head-off head-on prior-on') for mode in ['healthy','slow','unreachable']]
else: raise ValueError((product,stage))
for mode,n,name,arms in jobs:
    tag=os.environ.get('QAAS_BENCH_SERIES','')
    if tag: name=name+'-'+tag
    argv=[sys.executable,'-u','paired.py',product,mode,str(n),name+'.jsonl',*arms.split()]
    if stage=='failure':argv.append('--failure')
    print(name,flush=True)
    with (root/(name+'.progress')).open('w',encoding='utf8') as log:
        subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
