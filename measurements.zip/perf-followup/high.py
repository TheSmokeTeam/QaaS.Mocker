"""Normalize the high-assertion cross-check and keep paths/local diagnostic contents private."""
from pathlib import Path
import argparse,json,subprocess,sys
HERE=Path(__file__).resolve().parent;REV=HERE.parent/'revision-bench'
p=argparse.ArgumentParser();p.add_argument('--modes',default='healthy,slow');p.add_argument('--rounds',type=int,default=3)
a=p.parse_args(); name='followup-cross-final'
dest=REV/(name+'.jsonl')
assert not dest.exists(),dest
subprocess.run([sys.executable,'-u','cross.py','--label',name,'--out',dest.name,'--rounds',str(a.rounds),'--modes',a.modes,'--assertions','128'],cwd=REV,check=True)
rows=[]
for ln in dest.read_text().splitlines():
    r=json.loads(ln)
    new={k:v for k,v in r.items() if k in ('suite','case','round','mode','side','wall_s','exit','cpu_s','peak_working_set_bytes','sampled_peak_private_bytes','files','assertions_observed','assertions_per_s','requests_observed')}
    ledger=r.get('ledger') or {}
    new['accepted']=ledger.get('accepted',{});new['wire_bytes']=ledger.get('wire_body_bytes')
    assert new['assertions_observed']==128 and new['exit']==1, new
    rows.append(new)
for p in ('Runner','Mocker'):
    target=HERE/('supplement-'+p);target.mkdir(exist_ok=True)
    (target/'high-assertion-cross-check.json').write_text(json.dumps(rows,indent=2),encoding='utf8')

