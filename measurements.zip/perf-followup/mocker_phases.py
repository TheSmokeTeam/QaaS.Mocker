import json, os, subprocess, sys, time
from pathlib import Path
from contextlib import ExitStack
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'revision-bench'))
from common import assembly as find,cpu, memory, relay_for,wait_for_bulk, options
from cli_matrix import timed
def run():
    path=HERE/'supplement-Mocker';path.mkdir(exist_ok=True)
    out=path/'drain-phases.jsonl'
    if out.exists():raise FileExistsError(out)
    for n in range(1,4):
        for scenario in ['short','failure']:
            for mode in ['healthy','slow','unreachable']:
                for side in (['prior','head'] if n%2 else ['head','prior']):
                    with ExitStack() as stack:
                        relay=relay_for(stack,mode,19379)
                        host=find('Mocker','head')
                        if side=='prior':host=HERE/'before-Mocker'/host.name
                        case='mocker-failure.qaas.yaml' if scenario=='failure' else 'mocker.qaas.yaml'
                        flags=[] if scenario=='failure' else ['--run-locally']
                        argv=['dotnet',str(host),'run',str(ROOT/'bench'/case),'--no-env',*options(mode,relay),*flags]
                        record=HERE/'mocker-phase-current.json'
                        if record.exists():record.unlink()
                        env={**os.environ,'QAAS_USAGE_ENABLED':'true','QAAS_DRAIN_OBSERVATION':str(record),'DOTNET_STARTUP_HOOKS':str(ROOT/'revision-bench/DrainHook/bin/Release/net10.0/DrainHook.dll')}
                        env.pop('QAAS_USAGE_FLUSH_MS',None)
                        got=timed(argv,env,'fail' if scenario=='failure' else 0,HERE/'mocker-phase-current.log')
                        wait_for_bulk(relay)
                        ledger=relay.ledger.snapshot() if relay else {}
                        result=dict(round=n,case=scenario,mode=mode,arm=side,**got,drain=json.loads(record.read_text()),accepted=ledger.get('accepted',{}))
                        with out.open('a',encoding='utf8') as f:f.write(json.dumps(result)+'\n')
                        print(n,scenario,mode,side,round(result['drain']['elapsed_ms'],2),result['accepted'],flush=True)
if __name__=='__main__':run()

