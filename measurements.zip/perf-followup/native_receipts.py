import json, subprocess, time, uuid, sys, os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import requests
root=Path(__file__).resolve().parents[1]
dll=root/'Mocker/QaaS.Mocker.Example/bin/Release/net10.0/QaaS.Mocker.Example.dll'
es='http://127.0.0.1:19278'
requests.get(es,timeout=2).raise_for_status()
data=root/'dashboard-validation'
out=root/'mocker-drain-delivery'
out.mkdir(exist_ok=True)
setting = sys.argv[1]
if setting == 'default':
    os.environ.pop('QAAS_USAGE_FLUSH_MS',None)
else:
    os.environ['QAAS_USAGE_FLUSH_MS']=setting
runid='v2-'+setting+'-'+uuid.uuid4().hex[:12]
rows=[]
def probe(i,failed):
    owner=f'{runid}-{i}-{int(failed)}'
    fixture=(data/('mocker-fail.yaml' if failed else 'mocker.yaml')).read_text(encoding='utf-8-sig')
    fixture=fixture.replace('Port: 18145',f'Port: {18250+int(failed)}')
    fixture=fixture.replace('Team: Payments','Team: '+owner).replace('Team: Checkout','Team: '+owner)
    fixture=fixture.replace('  System:', '  ExtraLabels:\n    Project: ReceiptProject\n  System:')
    assert owner in fixture
    config=out/(owner+'.yaml')
    config.write_text(fixture)
    args=['dotnet',str(dll),'run',str(config),'--no-env','--send-logs','--elastic-uri',es]
    if not failed:args+=['--run-locally']
    begin=time.monotonic()
    run=subprocess.run(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=50,creationflags=subprocess.CREATE_NO_WINDOW)
    elapsed=time.monotonic()-begin
    trace=run.stdout.decode('utf-8',errors='replace')
    (out/(owner+'.log')).write_text(trace,encoding='utf-8')
    assert (run.returncode!=0)==failed,(run.returncode,trace[-2400:])
    if failed:
        assert 'Exception' in trace and 'HttpServer' in trace and 'Execution.Start' in trace,(run.returncode,trace[-2100:])
    return dict(owner=owner,failed=failed,elapsed=round(elapsed,3),exit=run.returncode)
if '--overlap' in sys.argv:
    with ThreadPoolExecutor(max_workers=2) as pool:
        for i in range(3):
            futures=[pool.submit(probe,i,fail) for fail in (False,True)]
            rows.extend(f.result() for f in futures)
else:
    for i in range(3):
        rows.extend(probe(i,fail) for fail in (False,True))
requests.post(es+'/qaas-*/_refresh',timeout=10).raise_for_status()
for row in rows:
    result=requests.post(es+'/qaas-*/_search',json={'size':100,'query':{'term':{'fields.Team.keyword':row['owner']}}},timeout=10);result.raise_for_status()
    events=[doc['_source']['fields'] for doc in result.json()['hits']['hits'] if doc['_source']['fields'].get('QaasEvent')]
    start=[x for x in events if x['QaasEvent']=='MockerExecutionStarted']
    end=[x for x in events if x['QaasEvent']=='MockerExecutionFinished']
    row['start']=len(start);row['terminal']=len(end)
    
    row['ok']=len(start)==len(end)==1 and end[0]['Failed']==int(row['failed']) and end[0]['AttemptId']==start[0]['AttemptId'] and end[0]['Outcome']==('mocker_error' if row['failed'] else 'success') and isinstance(end[0]['Features'],list) and end[0]['DurationMs']>=0 and end[0]['ProjectKnown'] and end[0]['Project']=='ReceiptProject'
print(json.dumps(rows,indent=2))
(out/(runid+'.json')).write_text(json.dumps(rows,indent=2))
if setting=='2000':
    assert all(r['ok'] for r in rows)

