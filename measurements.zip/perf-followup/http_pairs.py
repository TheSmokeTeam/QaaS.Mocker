"""Independent warmed host pairs. Sample one result per process pair; restart and swap serving ports."""
from pathlib import Path
import argparse,collections,json,statistics,sys
HERE=Path(__file__).resolve().parent
REV=HERE.parent/'revision-bench'
sys.path.insert(0,str(REV))
import http_matrix as http
raw_assembly=http.assembly
raw_metadata=http.metadata
def assembly(repo,build):
    if build=='prior':return HERE/('before-'+repo)/raw_assembly(repo,'head').name
    return raw_assembly(repo,build)
http.assembly=assembly
http.base_command.__globals__['assembly']=assembly
def metadata(repo,build):
    import hashlib
    host=assembly(repo,build)
    return {name:hashlib.sha256((host.parent/name).read_bytes()).hexdigest() for name in ('QaaS.Mocker.dll','QaaS.Mocker.Servers.dll')}
http.metadata=metadata
def main():
    p=argparse.ArgumentParser();p.add_argument('scheme',choices=('base','switch','prior'));p.add_argument('pairs',type=int);p.add_argument('--mode',default='healthy')
    a=p.parse_args()
    label='httpfollowup-'+a.scheme+'-'+a.mode
    dst=HERE/(label+'.jsonl')
    if dst.exists():raise FileExistsError(dst)
    arms=({'off':{'build':'base','httpAggregation':False},'on':{'build':'head','httpAggregation':True}} if a.scheme=='base' else
          {'off':{'build':'head','httpAggregation':True,'env':{'QAAS_USAGE_ENABLED':'false'}},'on':{'build':'head','httpAggregation':True,'env':{'QAAS_USAGE_ENABLED':'true'}}} if a.scheme=='switch' else
          {'off':{'build':'prior','httpAggregation':True},'on':{'build':'head','httpAggregation':True}})
    conf=HERE/(label+'.json');conf.write_text(json.dumps(arms))
    def append(name,row):
        reduced={k:row[k] for k in ('case','mode','round','side','files','rps','count','p95_ms','cpu_us_per_req','peak_working_set_bytes','private_bytes','startup_s','stop_s','stop','sent_including_readiness_and_warmup') if k in row}
        if 'ledger' in row and row['ledger'] is not None:
            leg=row['ledger']
            reduced.update(accepted=leg['accepted'],http_totals=leg['http_totals'],wire_body_bytes=leg['wire_body_bytes'])
        reduced['host_pair']=host_no
        output=dst if 'rps' in reduced else HERE/(label+'.delivery.jsonl')
        with output.open('a',encoding='utf8') as f:f.write(json.dumps(reduced)+'\n')
    http.append=append
    for host_no in range(1,a.pairs+1):
        args=argparse.Namespace(arms=str(conf),label=label,out=dst.name,rounds=1,start=host_no,seconds=5,settle=12,concurrency=16,warmup=5000,swap=host_no%2==0)
        http.measure(args,a.mode,'mixed')
    print('finished',label,flush=True)
if __name__=='__main__':main()
