"""Paired whole-process benchmark for the real QaaS CLIs on Windows."""
import argparse, collections, datetime, hashlib, json, os, random, statistics, subprocess, sys, time
from pathlib import Path
from contextlib import ExitStack
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'revision-bench'))
from common import assembly, cpu, memory, relay_for, wait_for_bulk, options

import re

def one(product, arm, mode, fixture, relay, round_no, out):
    build, switch = arm.split('-')
    enabled = switch != 'off'
    assert switch in ('on','off') or (product=='Mocker' and switch.startswith('ms') and switch[2:].isdigit())
    host = assembly(product, 'base' if build == 'base' else 'head')
    if build in ('prior','controlprior'):
        host = HERE / ('before-' + product) / host.name
    if build == 'next':
        folder=Path((HERE/('next-'+product+'.txt')).read_text(encoding='utf-8-sig').strip())
        host = folder/host.name
    if build in ('stock','lean'):
        host = ROOT/'framework-client-debug-probe'/('client-debug-stock' if build=='stock' else 'client-debug-omitted')/host.name
    source = host.parent / ('QaaS.' + product + '.dll')
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    args = ['dotnet', str(host)]
    is_failure = 'failure' in fixture.name
    if product == 'Runner':
        args += ['execute', str(fixture)]
    else:
        args += ['run', str(fixture), '--no-env']
        if not is_failure: args.append('--run-locally')
    args += options(mode, relay)
    env = {**os.environ, 'QAAS_USAGE_ENABLED': 'true' if enabled else 'false'}
    env.pop('QAAS_USAGE_FLUSH_MS', None)
    if switch.startswith('ms'): env['QAAS_USAGE_FLUSH_MS'] = switch[2:]
    logdir = HERE/'logs'/out.stem
    logdir.mkdir(parents=True,exist_ok=True)
    log = logdir / (str(round_no) + '-' + arm + '.log')
    utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    peak = private = 0
    with log.open('wb') as stream:
        t = time.perf_counter()
        with subprocess.Popen(args, cwd=ROOT/'revision-bench', env=env, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT) as p:
            while p.poll() is None:
                try:
                    m = memory(p)
                    peak = max(peak, m['peak_working_set'])
                    private = max(private, m['private'])
                except OSError:
                    if p.poll() is None: raise
                try: p.wait(.025)
                except subprocess.TimeoutExpired: pass
                if time.perf_counter() - t > 120:
                    p.kill()
                    raise TimeoutError(args)
            wall = time.perf_counter() - t
            child_cpu = cpu(p)
            assert (p.returncode != 0 if is_failure else p.returncode == 0), log
            exit_code = p.returncode
    logs = log.read_text(encoding='utf8', errors='replace')
    if product == 'Runner':
        assert logs.count('Running Act execution with executionId') == 1 and logs.count('Running Run execution with executionId') == 4, log
    wait_for_bulk(relay)
    data = relay.ledger.snapshot() if relay else {}
    counts = data.get('accepted', {})
    if switch == 'off': assert not any(k != '(diagnostic)' and v for k,v in counts.items()), counts
    if product == 'Runner' and mode == 'healthy':
        assert counts.get('(diagnostic)') == 10, counts
        assert counts.get('RunnerExecutionStarted', 0) == counts.get('RunnerExecutionFinished', 0) == (5 if switch == 'on' and build != 'base' else 0), counts
    dels = [d for d in data.get('usage_samples',[]) if d.get('QaasEvent') in ('MockerExecutionStarted','MockerExecutionFinished')]
    for d in dels:
        assert d.get('Team') == 'PerfLab' and d.get('TeamKnown') is True, d
    matched = len(dels)==2 and len({d['AttemptId'] for d in dels})==1 and {d['QaasEvent'] for d in dels}=={'MockerExecutionFinished','MockerExecutionStarted'}
    row = dict(fixture=fixture.name,exit_code=exit_code,diagnostic_lines=sum(1 for ln in logs.splitlines() if re.match(r'^\[\d\d:\d\d:\d\d ',ln) and not any(k in ln for k in ['ExecutionStarted','ExecutionFinished','MockerHttpRequests'])),matched_mocker_pair=matched if product=='Mocker' and enabled and relay else None,product=product, arm=arm, mode=mode, round=round_no, started_utc=utc, runtime_sha256=digest,framework_sha256=hashlib.sha256((host.parent/'QaaS.Framework.Executions.dll').read_bytes()).hexdigest(),entry_sha256=hashlib.sha256(host.read_bytes()).hexdigest(),servers_sha256=hashlib.sha256((host.parent/'QaaS.Mocker.Servers.dll').read_bytes()).hexdigest() if product=='Mocker' else None, wall_s=wall, cpu_s=child_cpu,
               peak_bytes=peak, peak_private=private, accepted=counts, emitted=data.get('emitted',{}), wire_bytes=data.get('wire_body_bytes'), bulk_bytes=data.get('ndjson_bytes'),bulk_posts=data.get('posts'),bulk_elapsed_ms=[round(1000*(b['ack']-b['t']),3) for b in data.get('timeline',[])])
    with out.open('a', encoding='utf8') as fp: fp.write(json.dumps(row)+'\n')
    print(round_no, mode, arm, round(wall,3), round(peak/1048576,1), counts, flush=True)

def run():
    p = argparse.ArgumentParser()
    p.add_argument('product',choices=('Runner','Mocker'));p.add_argument('mode');p.add_argument('blocks',type=int);p.add_argument('output')
    p.add_argument('--failure',action='store_true');p.add_argument('arms',nargs='+');p.add_argument('--seed',type=int,default=73541)
    a=p.parse_args()
    out=HERE/a.output
    if out.exists(): raise FileExistsError(out)
    fixture = ROOT/'revision-bench'/'phase-identical-batch.yaml' if a.product=='Runner' else ROOT/'bench'/('mocker-failure.qaas.yaml' if a.failure else 'mocker.qaas.yaml')
    # Each group of k blocks puts every arm exactly once in every launch position.
    rng=random.Random(a.seed)
    primer=out.with_suffix('.primer.jsonl')
    for arm in a.arms:
        with ExitStack() as stack:
            one(a.product, arm, a.mode, fixture, relay_for(stack,a.mode,19379), 0, primer)
    for first in range(0,a.blocks,len(a.arms)):
        order=list(a.arms);rng.shuffle(order)
        shifts=list(range(len(order)));rng.shuffle(shifts)
        for idx, shift in enumerate(shifts[:a.blocks-first]):
            for arm in order[shift:]+order[:shift]:
                with ExitStack() as stack:
                    relay=relay_for(stack,a.mode,19379)
                    one(a.product,arm,a.mode,fixture,relay,first+idx+1,out)

if __name__=='__main__':run()

