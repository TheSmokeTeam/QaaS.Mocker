# Mocker short-process diagnostic

| Usage | Round | CPU (ms) | Peak working set (MiB) | GC tick weight (MiB) | Modules | JIT starts | Callback (ms) | Callback working set change (MiB) | Accepted start/finish |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| off | 1 | 2297 | 136.40 | 8.79 | 177 | 4862 | 0.00 | 0.00 | 0/0 |
| on | 1 | 1953 | 149.64 | 10.86 | 212 | 5586 | 125.30 | 12.26 | 1/1 |
| off | 2 | 1766 | 136.43 | 8.80 | 175 | 4842 | 0.00 | 0.00 | 0/0 |
| on | 2 | 3375 | 149.48 | 11.48 | 212 | 6005 | 125.52 | 10.13 | 1/1 |
| off | 3 | 2453 | 136.45 | 8.76 | 175 | 4859 | 0.00 | 0.00 | 0/0 |
| on | 3 | 2469 | 147.84 | 11.45 | 212 | 5566 | 125.67 | 9.23 | 1/1 |

Modules observed in every enabled trace and no disabled trace: Microsoft.AspNetCore.Authentication.Abstractions, Microsoft.AspNetCore.Authorization, Microsoft.AspNetCore.Connections.Abstractions, Microsoft.AspNetCore.HostFiltering, Microsoft.AspNetCore.Hosting.Server.Abstractions, Microsoft.AspNetCore.Http, Microsoft.AspNetCore.Http.Extensions, Microsoft.AspNetCore.HttpOverrides, Microsoft.AspNetCore.Routing.Abstractions, Microsoft.AspNetCore.Server.IIS, Microsoft.AspNetCore.Server.IISIntegration, Microsoft.AspNetCore.Server.Kestrel, Microsoft.AspNetCore.Server.Kestrel.Transport.NamedPipes, Microsoft.AspNetCore.Server.Kestrel.Transport.Quic, Microsoft.AspNetCore.Server.Kestrel.Transport.Sockets, Microsoft.CSharp, Microsoft.Extensions.Configuration.Json, Microsoft.Extensions.DependencyInjection, Microsoft.Extensions.Diagnostics, Microsoft.Extensions.FileProviders.Abstractions, Microsoft.Extensions.FileProviders.Physical, Microsoft.Extensions.Hosting, Microsoft.Extensions.Logging, Microsoft.Extensions.Logging.Configuration, Microsoft.Extensions.Logging.Console, Microsoft.Extensions.Logging.Debug, Microsoft.Extensions.Logging.EventLog, Microsoft.Extensions.Logging.EventSource, Microsoft.Extensions.ObjectPool, Microsoft.Extensions.Options, Microsoft.Extensions.Options.ConfigurationExtensions, Microsoft.Net.Http.Headers, System.Diagnostics.EventLog, System.IO.Pipes, System.Net.Quic.

| Enabled callback sample | GC tick weight (MiB) | Top allocation sample type | JIT families | Managed CPU families (inclusive ms) |
|---|---:|---|---|---|
| 1 | 1.95 | System.Byte[] | Other runtime 369.0, Elastic native sink/client 116.0, Serilog batching/logging 37.0, Kestrel/ASP.NET 9.0, HTTP/network 8.0, QaaS 4.0 | Other runtime 181.9, QaaS 95.6, Kestrel/ASP.NET 93.6, Elastic native sink/client 70.4, HTTP/network 55.3, Compression 43.9 |
| 2 | 2.16 | System.String | Other runtime 375.0, Elastic native sink/client 86.0, Serilog batching/logging 37.0, Kestrel/ASP.NET 9.0, HTTP/network 8.0, QaaS 4.0 | Other runtime 175.4, QaaS 86.9, Elastic native sink/client 84.5, Kestrel/ASP.NET 69.0, HTTP/network 66.8, Compression 62.5 |
| 3 | 2.14 | RuntimeTypeCache | Other runtime 378.0, Elastic native sink/client 87.0, Serilog batching/logging 37.0, Kestrel/ASP.NET 9.0, HTTP/network 8.0, QaaS 4.0 | Other runtime 154.8, QaaS 75.6, Elastic native sink/client 72.6, Kestrel/ASP.NET 68.8, HTTP/network 52.6, Compression 48.8 |

## What ran during the extra time

Peak Windows working set medians were 136.43 MiB with usage off and 149.48 MiB on. Managed allocation-tick weights were 8.79 and 11.45 MiB per process, respectively. These measure different quantities.

The three callback windows contained 13, 13, 13 ASP.NET/Kestrel module-load events. Across enabled samples, stacks containing the native Elastic sink/client contributed 70–84 ms of inclusive managed CPU weight. Stacks containing Kestrel/ASP.NET contributed 69–94 ms. The redirected local CLI starts the configured server in a background task. Both its startup and the native log delivery therefore run during the connected shutdown wait. The measurements do not apportion resident bytes between those paths.

## Interpretation

All children run the actual connected short CLI through the existing diagnostic callback wrapper; absolute profile elapsed time is instrumented.
Windows peak working set includes resident managed/native heaps, stacks, JIT code and mapped images. It is not the managed GC allocation total.
Allocation ticks estimate allocation traffic from the sampled allocating type; they cannot identify retained or resident bytes.
JIT starts count compilation requests, not native machine-code bytes; loaded module names exclude paths and CLR rundown duplicates.
Managed CPU weights are sample-derived and inclusive across families. Unmanaged intervals include waits/non-managed work and do not establish native CPU consumption. OS CPU is separate.
Callback boundaries use file modification time immediately after the existing probe measured the real callback. The redirected-input log is a common near-end marker in both arms; stdout/file scheduling can shift small intervals.
Raw traces remain local. Counts from the relay are accepted native Elasticsearch bulk documents.
