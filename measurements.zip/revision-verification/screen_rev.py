import json
import sys
import time
import os
from pathlib import Path
from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
receipt = json.loads((HERE / os.environ.get("QAAS_SCREEN_RUN","live-3d7cfd32") /"receipt.json").read_text())
out = Path(os.environ.get("QAAS_SCREEN_DIR",str(HERE/"screens")))
out.mkdir(exist_ok=True)

def shot(page, product, label):
    page.screenshot(path=out / (product.lower() + "-" + label + ".png"), animations="disabled")
    (out / (product.lower() + "-" + label + ".txt")).write_text(page.locator("body").inner_text(), encoding="utf-8")

def render(browser, product):
    uid = "qaas-" + product.lower() + "-usage"
    url = f"http://127.0.0.1:13045/d/{uid}/{uid}?from={receipt['from']}&to={receipt['to']}&timezone=utc&theme=light&kiosk"
    page = browser.new_page(viewport={"width": 1536, "height": 940}, device_scale_factor=1)
    rate_queries=[]
    def observe(request):
        if product=="Mocker" and request.method=="POST" and "/api/ds/query" in request.url:
            for query in (request.post_data_json or {}).get("queries",[]):
                if query.get("alias")=="Requests / s":
                    rate_queries.append({"intervalMs":query["intervalMs"],"maxDataPoints":query.get("maxDataPoints")})
    page.on("request",observe)
    page.goto(url, wait_until="domcontentloaded", timeout=60000)
    from re import compile
    page.get_by_text("Runs completed",exact=True).first.wait_for(timeout=45000)
    page.wait_for_timeout(4200)
    print(page.locator("body").inner_text()[:3200], flush=True)
    shot(page, product, "diagnostic")
    rate = compile(r"^16\.(?:7|67)\s*%$") if product == "Runner" else compile(r"^50(?:\.0+)?\s*%$")
    page.get_by_text(rate).first.wait_for(timeout=15000)
    page.get_by_text("Local", exact=True).first.wait_for(timeout=20000)
    page.wait_for_timeout(500)
    shot(page, product, "overview")
    section = "Test execution" if product == "Runner" else "HTTP traffic and failures"
    page.mouse.move(700,680)
    heading=page.get_by_text(section,exact=True).first
    for _ in range(10):
        if heading.count(): break
        page.mouse.wheel(0,650)
        page.wait_for_timeout(220)
    heading.evaluate("""(el) => {el.scrollIntoView({block:'start'}); for(let node=el.parentElement; node; node=node.parentElement) {if(node.scrollHeight>node.clientHeight && ['auto','scroll'].includes(getComputedStyle(node).overflowY)) {node.scrollTop -= 112; break;}}}""",timeout=7500)
    page.wait_for_timeout(700)
    if product == "Mocker":
        page.get_by_text(compile(r"^10(?:\.0+)?\s*%$")).first.wait_for(timeout=15000)
        page.get_by_text(compile(r"^20(?:\.0+)?\s*%$")).nth(1).wait_for(timeout=20000)
        assert rate_queries and all(q["intervalMs"]>=10000 for q in rate_queries),rate_queries
        (out/"mocker-browser-interval.json").write_text(json.dumps(rate_queries,indent=2))
    else:
        page.get_by_text("Batch case", exact=True).first.wait_for(timeout=15000)
    title=page.get_by_text("Completed requests" if product=="Mocker" else "Test plans executed",exact=True).first
    for _ in range(4):
        rect=title.bounding_box()
        if rect and 125 <= rect["y"] <= 295:break
        if rect:page.mouse.wheel(0,int(rect["y"]-186))
        page.wait_for_timeout(300)
    assert 105 < title.bounding_box()["y"] < 350
    shot(page, product, "detail")
    print(product, "two screenshots saved", flush=True)
    page.goto(url + "&var-Team=Payments", wait_until="domcontentloaded")
    page.get_by_text(compile(r"^100(?:\.0+)?\s*%$")).first.wait_for(timeout=20000)
    filtered = page.locator("body").inner_text()
    (out / (product+"-filtered.txt")).write_text(filtered, encoding="utf-8")
    assert "Commerce" not in filtered
    print(product,"Payments filter shows 100% unsuccessful finishes",flush=True)
    page.goto(url.replace("from="+str(receipt["from"]), "from="+str(receipt["from"]-7200000)).replace("to="+str(receipt["to"]), "to="+str(receipt["from"]-3600000)),wait_until="domcontentloaded")
    page.get_by_text("Runs started", exact=True).first.wait_for(timeout=15000)
    page.get_by_text(compile(r"^(?:No data|—)$")).first.wait_for(timeout=25000)
    text = page.locator("body").inner_text()
    (out / (product+"-empty.txt")).write_text(text, encoding="utf-8")
    assert ("No data" in text or "—" in text),text[:1300]
    page.close()

if __name__ == "__main__":
    with sync_playwright() as p:
        browser = p.chromium.launch(channel="msedge",headless=True,args=["--disable-gpu","--disable-extensions","--disable-background-networking"])
        for product in sys.argv[1:] or ["Runner", "Mocker"]:
            render(browser, product)
        browser.close()
