"""Independent oracle. Compute expectations from emitted originals and separately labeled fault inputs."""
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from contextlib import redirect_stdout
import copy,json,math,sys,traceback
from check_charts import panel_frames
from canonical import req

def tms(s):return int(datetime.fromisoformat(s).timestamp()*1000)
def reconciled(rows,p):
    keys=defaultdict(lambda:defaultdict(list))
    for e in rows:
        f=e['fields']
        if not f['QaasEvent'].startswith(p):continue
        typ=f['QaasEvent'][len(p):];key=(f['ServerId'],f['BatchSequence']) if typ=='HttpRequests' else f['AttemptId']
        keys[key][typ].append(e)
    result=[]
    for key,phases in keys.items():
        dst={};conflict=False
        for phase,deliveries in sorted(phases.items(),reverse=True):
            first=min(deliveries,key=lambda e:tms(e['@timestamp']))
            values=first['fields'];tt=tms(first['@timestamp'])
            ignore={'SourceContext','Hostname','ExecutionId'}
            norm=lambda f:{k:v for k,v in f.items() if k not in ignore and v is not None}
            conflict |= any(norm(e['fields'])!=norm(values) for e in deliveries)
            if 'time' in dst:
                for k in ('Team','Project','System','TeamKnown','ProjectKnown','SystemKnown','Features','Environment','ExecutionType','Version','IsBatch','IsCase'):
                    if k in dst and k in values and dst[k]!=values[k]:conflict=True
            dst.update({k:v for k,v in values.items() if v is not None});dst.setdefault('time',[]).append(tt)
            name={'ExecutionStarted':'start','ExecutionFinished':'finish','HttpRequests':'batch'}[phase]
            dst[name]=tt
        dst['conflict']=conflict;dst['Features']=dst.get('Features') or ['none'];dst['Environment']=dst.get('Environment') or 'Unknown';dst['Version']=dst.get('Version') or 'Unknown'
        for axis in ('Team','System','Project'):
            if not dst.get(axis+'Known') or not dst.get(axis):dst[axis]='(unattributed)';dst[axis+'Known']=False
        if 'IsCase' in dst:
            dst['Invocation']= ('Batch case' if dst['IsCase'] else 'Batch command') if dst['IsBatch'] else ('Named case' if dst['IsCase'] else 'Standalone')
        result.append(dst)
    return result

def approx(a,b):
    if a is None or b is None:return a is b
    if isinstance(a,(float,int)) and isinstance(b,(float,int)):return math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-9)
    if isinstance(a,(tuple,list)) and isinstance(b,(tuple,list)):return len(a)==len(b) and all(approx(x,y) for x,y in zip(a,b))
    if isinstance(a,dict) and isinstance(b,dict):return set(a)==set(b) and all(approx(a[k],b[k]) for k in a)
    return a==b

def oracle(p,rows,wind,filters,frames):
    lo,hi=wind['start'],wind['end'];width=max(1000,int((hi-lo)/180));mid=lo+(hi-lo)//2
    def include(r):
        return any(lo<=t<=hi for t in r['time']) and all(v in (r[k] if isinstance(r[k],list) else [r[k]]) for k,v in filters.items())
    arrived=[r for r in reconciled(rows,p) if include(r)]
    valid=[r for r in arrived if not r['conflict']]
    starts,ends,http=([r for r in valid if phase in r and lo<=r[phase]<=hi] for phase in ('start','finish','batch'))
    known=[r for r in ends if r.get('AssertionsExecuted') is not None]
    sums=lambda rs,k:sum(r[k] for r in rs if r.get(k) is not None)
    nofinish=[r for r in starts if r['start']<=hi-900000 and ('finish' not in r or r['finish']>hi)]
    results={};tested=set()
    def check(k,expect,actual):
        tested.add(k)
        if not approx(expect,actual):results[k]={'expected':repr(expect)[:1500],'actual':repr(actual)[:1500]}
    def scalar(k,expect,fac=-1):
        f=frames[k]
        actual=f[0]['values'][fac][0] if f and f[0]['values'][fac] else None
        check(k,expect,actual)
    def cnt(k,rows):scalar(k,len(rows) if rows else None)
    cnt('Runs started',starts);cnt('Runs completed',ends);cnt('Unknown attribution',[r for r in starts if not all(r[axis+'Known'] for axis in ('Team','System','Project'))]);cnt('No observed finish after 15 min',nofinish)
    cnt('Finish without observed start',[r for r in ends if 'start' not in r]);cnt('Conflicting replays',[r for r in arrived if r['conflict']])
    scalar('Unsuccessful finishes',sums(ends,'Failed')/len(ends) if ends else None)
    scalar('Completed runs / s',len(ends)*1000/(hi-lo) if ends else None)
    durations=sorted(r['DurationMs'] for r in ends if r.get('DurationMs') is not None)
    # Small fixture cardinality places t-digest 95% within the upper endpoint.
    scalar('P95 run duration',max(durations) if durations else None)
    for axis in ('Team','Project','System'):
        two=[{r[axis] for r in starts if r[axis+'Known'] and (r['start']<mid)==left} for left in [True,False]]
        union=two[0]|two[1]
        scalar('Active '+axis.lower()+'s',len(union) if union else None)
        k='Returning '+axis.lower()+'s';f=frames[k]
        expected=[len(two[0]),len(two[1]),len(union),len(two[0]&two[1]) if all(two) else None] if union else []
        check(k,expected,[a[0] for a in f[0]['values'][1:]] if f else [])
    def series(k,rs,t,key,value=lambda r:1,bucket_ms=width):
        groups=defaultdict(Counter)
        for r in rs:
            for name in key(r):groups[name][(r[t]//bucket_ms)*bucket_ms]+=value(r)
        actual={f['name']:dict(zip(*f['values'])) for f in frames[k] if f['values'][0]}
        check(k,dict(groups),actual)
    series('Starts by environment',starts,'start',lambda r:[r['Environment']]);series('Finished outcomes',ends,'finish',lambda r:[r['Outcome']]);series('Feature use',starts,'start',lambda r:r['Features'])
    def groups(rs,axes):
        g=defaultdict(list)
        for r in rs:g[tuple(r[a] for a in axes)].append(r)
        return g
    def table(k,rs,axes,fn,others):
        expected={ks:fn(v) for ks,v in groups(rs,axes).items()};actual={}
        for f in frames[k]:
            for vals in zip(*f['values']):
                row=dict(zip(f['cols'],vals));key=tuple(row['event.'+axis] for axis in axes)
                actual[key]=[row[n] for n in others]
        check(k,expected,actual)
    table('Usage by team, project and system',starts,['Team','Project','System'],lambda v:[len(v)],['Count'])
    table('Usage by version and mode',starts,['Version','ExecutionType'],lambda v:[len(v)],['Count'])
    table('Outcomes by team and system',ends,['Team','System'],lambda v:[len(v),sums(v,'Failed'),sums(v,'Failed')/len(v)],['Count','Sum','Average'])
    if p=='Runner':
        scalar('Test plans executed',sums(ends,'TestsExecuted') if any('TestsExecuted' in r for r in ends) else None)
        scalar('Assertions executed',sums(known,'AssertionsExecuted') if known else None)
        scalar('Assertions / s',sums(known,'AssertionsExecuted')*1000/(hi-lo) if known else None)
        cnt('Unmeasured assertion counts',[r for r in ends if r.get('AssertionsExecuted') is None])
        key='Mode, case and batch'
        table(key,ends,['ExecutionType','Invocation'],lambda v:[len(v),sums(v,'TestsExecuted'),sums(v,'AssertionsExecuted') if any('AssertionsExecuted' in r for r in v) else None],['Count','Sum event.TestsExecuted','Bucket Script'])
    else:
        total=sums(http,'Requests');scalar('Completed requests',total if http else None)
        for label,k in [('Handler error rate','HandlerErrors'),('Route miss rate','Misses'),('HTTP 5xx rate','Http5xx')]: scalar(label,sums(http,k)/total if total else None)
        # Completed requests arrive in ten-second flush windows. A short chart cannot resolve them more finely.
        batch_bucket_ms=max(width,10_000)
        series('HTTP requests / s',http,'batch',lambda r:['Requests / s'],lambda r:r['Requests']*1000/batch_bucket_ms,bucket_ms=batch_bucket_ms)
        rs=[dict(r,series=label,count=r[k]) for r in http for label,k in [('Handler errors','HandlerErrors'),('Route misses','Misses'),('HTTP 5xx','Http5xx')]]
        series('HTTP outcomes over time',rs,'batch',lambda r:[r['series']],lambda r:r['count'],bucket_ms=batch_bucket_ms)
        num=['Requests','HandlerErrors','Misses','Http5xx']
        table('Busiest HTTP server instances',http,['ServerId','Port'],lambda v:[sums(v,k) for k in num],['Sum event.'+k for k in num])
    key='Recent unsuccessful executions';cols=['finish','Team','Project','System','ExecutionType','Outcome','DurationMs','AttemptId']
    expect=[[r[c] for c in cols] for r in sorted((r for r in ends if r['Failed']),key=lambda r:r['finish'],reverse=True)[:25]]
    actual=[]
    for f in frames[key]:
        for vals in zip(*f['values']):
            d=dict(zip(f['cols'],vals));actual.append([d['event.'+('FinishedAt' if c=='finish' else c)] for c in cols])
    check(key,expect,actual)
    assert tested==set(frames),(tested-set(frames),set(frames)-tested)
    return {'checked':len(tested),'failures':results}
def main():
    P=Path(__file__).parent/'live-3d7cfd32'
    receipt=json.loads((P/'receipt.json').read_text())
    genuine=json.loads((P/'events.json').read_text())
    replays=json.loads((P/'controlled-replays.json').read_text())
    faults=json.loads((P/'controlled-events.json').read_text())
    w={'start':receipt['from'],'end':receipt['to']}
    wf=json.loads((P/'controlled-window.json').read_text())
    assert len(receipt['http'])+len(receipt['witness'])==10 and receipt['quiet_batches']==0
    assert [r[1] for r in receipt['witness']]==[200,200]
    assert [r[1] for r in receipt['http']].count(404)==2
    assert sum(x[1]>=500 for x in receipt['http'])==2
    runs=[('live',w,{},False),('widened',dict(w,end=w['end']+1200000),{},False),('owner',w,{'Team':'Commerce'},False),('feature',w,{'Features':None},False),('unknown',w,{'Project':'(unattributed)'},False),('empty',w,{'Team':'nonexistent-lab-owner'},False),('faults',wf,{},True),('boundary',dict(wf,end=wf['start']+45*60000),{},True),('literal',wf,{'Team':'Unknown'},True)]
    allres={}
    for scenario,window,fl,controlled in runs:
        if len(sys.argv)>1 and scenario not in sys.argv[1:]:continue
        for p in ['Runner','Mocker']:
            flt=dict(fl)
            if scenario=='feature':flt['Features']='Assertions' if p=='Runner' else 'https'
            path=P/(p+'-'+scenario+'-frames.json')
            with (P/(p+'-'+scenario+'-api.log')).open('w') as out,redirect_stdout(out):
                f=panel_frames(p,window,flt,'qaasverify-control-'+p.lower() if controlled else None)
            path.write_text(json.dumps(f,indent=2))
            result=oracle(p,faults if controlled else genuine+replays,window,flt,f)
            allres[p+'/'+scenario]=result
            print(p,scenario,result,flush=True)
    (P/('oracle-'+('-'.join(sys.argv[1:]) or 'all')+'.json')).write_text(json.dumps(allres,indent=2))
    return 1 if any(q['failures'] for q in allres.values()) else 0
if __name__=='__main__':sys.exit(main())
