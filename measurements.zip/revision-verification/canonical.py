"""Render/install the same native Elasticsearch requests a reviewer opens in Kibana Console."""
import json
import re
from pathlib import Path
import requests

ROOT = Path(__file__).resolve().parents[1]
ES = "http://127.0.0.1:19278"
PIPE = "qaas-usage-stamp-v1"
STAMP = """def f = ctx.fields;
if (f == null || f.AttemptId == null || f.QaasEvent == null) return;
if (f.QaasEvent == 'MockerHttpRequests' && f.ServerId != null && f.BatchSequence != null) {
  ctx.qaas_usage_key = 'm/http/' + f.ServerId + '/' + f.BatchSequence;
} else if (f.QaasEvent == 'RunnerExecutionStarted' || f.QaasEvent == 'RunnerExecutionFinished') {
  ctx.qaas_usage_key = 'r/run/' + f.AttemptId;
} else if (f.QaasEvent == 'MockerExecutionStarted' || f.QaasEvent == 'MockerExecutionFinished') {
  ctx.qaas_usage_key = 'm/run/' + f.AttemptId;
}"""
MAP = """def f = params._source.fields;
def kind = f.QaasEvent == 'MockerHttpRequests' ? 'batch' : (f.QaasEvent.endsWith('Started') ? 'start' : 'finish');
def values = new HashMap();
for (def key : params.keep) {
  if (f[key] != null) values[key] = f[key];
}
long ts = doc['@timestamp'].value.toInstant().toEpochMilli();
def prior = state[kind];
if (prior != null && !prior.values.equals(values)) state.conflict = true;
if (prior == null || ts < prior.at) state[kind] = ['at':ts, 'values':values];"""
REDUCE = """def phases = new HashMap();
boolean conflict = false;
for (def part : states) {
  if (part == null) continue;
  if (part.conflict == true) conflict = true;
  for (def phase : ['start','finish','batch']) {
    def next = part[phase];
    if (next == null) continue;
    def old = phases[phase];
    if (old != null && !old.values.equals(next.values)) conflict = true;
    if (old == null || next.at < old.at) phases[phase] = next;
  }
}
def start = phases.start;
def finish = phases.finish;
def batch = phases.batch;
def row = new HashMap();
if (start != null && finish != null) {
  for (def key : ['Team','Project','System','TeamKnown','ProjectKnown','SystemKnown','Version','ExecutionType','Environment','Features','IsBatch','IsCase']) {
    if (start.values[key] != finish.values[key]) conflict = true;
  }
}
if (batch != null) {
  row.putAll(batch.values);
  row.Kind = 'HTTP';
  row.BatchAt = batch.at;
  row.Time = [batch.at];
} else {
  row.Kind = 'Execution';
  row.Time = new ArrayList();
  if (finish != null) {
    row.putAll(finish.values);
    row.FinishedAt = finish.at;
    row.Time.add(finish.at);
  }
  if (start != null) {
    row.putAll(start.values);
    row.StartedAt = start.at;
    row.Time.add(start.at);
  }
}
if (row.Features == null || (row.Features instanceof List && row.Features.isEmpty())) row.Features = ['none'];
if (row.Environment == null) row.Environment = 'Unknown';
if (row.Version == null) row.Version = 'Unknown';
for (def axis : ['Team','Project','System']) {
  if (row[axis+'Known'] != true || row[axis] == null) {
    row[axis] = '(unattributed)';
    row[axis+'Known'] = false;
  }
}
if (row.containsKey('IsCase')) {
  row.Invocation = row.IsBatch == true ? (row.IsCase == true ? 'Batch case' : 'Batch command')
                                       : (row.IsCase == true ? 'Named case' : 'Standalone');
}
row.Conflict = conflict;
return row;"""

common = ["AttemptId","Team","System","Project","TeamKnown","SystemKnown","ProjectKnown","Version",
          "ExecutionType","Environment","Features","DurationMs","Outcome","Failed"]
product_fields = {"Runner":["IsBatch","IsCase","TestsExecuted","AssertionsExecuted"],
                  "Mocker":["ServerId","BatchSequence","Port","Requests","HandlerErrors","Misses","Http5xx"]}
dates = ["Time","StartedAt","FinishedAt","BatchAt"]
raw = {"qaas_usage_key":{"type":"keyword"}, "qaas_usage_ingested":{"type":"date"}}

def definitions(product):
    name = "qaasusage-" + product.lower() + "-v1"
    keep = common + product_fields[product]
    types = {}
    for field in keep + dates + ["Kind","Conflict","Invocation"]:
        data_type = ("date" if field in dates else
                     "boolean" if field.endswith("Known") or field in ["IsBatch","IsCase","Conflict"] else
                     "double" if field == "DurationMs" else
                     "long" if field in ["Failed","TestsExecuted","AssertionsExecuted","BatchSequence","Port","Requests","HandlerErrors","Misses","Http5xx"] else "keyword")
        types[field] = {"type":data_type}
    return [
        ("PUT","/_ingest/pipeline/"+PIPE,{"description":"Stamp QaaS usage records at ingestion for late/replayed event reconciliation.",
           "processors":[{"script":{"if":"ctx.fields?.AttemptId != null","source":STAMP}},
                         {"set":{"if":"ctx.qaas_usage_key != null","field":"qaas_usage_ingested","value":"{{{_ingest.timestamp}}}"}}]}),
        ("PUT","/_component_template/qaas-usage-fields-v1",{"template":{"mappings":{"properties":raw}}}),
        ("PUT","/"+name,{"mappings":{"dynamic":"strict","properties":{"key":{"type":"keyword"},"event":{"properties":types}}}}),
        ("PUT","/_transform/"+name,{"description":product+" usage. Reconcile each attempt across phases and each nonempty HTTP batch across deliveries.",
           "source":{"index":"qaas-20*","query":{"prefix":{"qaas_usage_key":product[0].lower()+"/"}}},
           "dest":{"index":name},"frequency":"30s","sync":{"time":{"field":"qaas_usage_ingested","delay":"10s"}},
           "settings":{"max_page_search_size":200},
           "pivot":{"group_by":{"key":{"terms":{"field":"qaas_usage_key"}}},"aggregations":{"event":{"scripted_metric":{
               "params":{"keep":keep},"init_script":"state.conflict = false;","map_script":MAP,
               "combine_script":"return state;","reduce_script":REDUCE}}}}}),
        ("POST","/_transform/"+name+"/_start",None)]

def pretty(obj):
    data=json.dumps(obj,indent=2)
    for script in [STAMP,MAP,REDUCE]:
        data=data.replace(json.dumps(script),'"""\n'+script+'\n"""')
    return data

def render(product):
    folder=ROOT/product/"observability";folder.mkdir(exist_ok=True)
    instructions = [
        "# Run in Kibana Dev Tools. The first two resources are shared by Runner and Mocker.",
        "# Attach the ingest pipeline and field mappings to the daily log indices as described in the README before starting.",
        "# Creating the destination and transform is a one-time operation. Keep existing data on reconfiguration.",""]
    for method,path,body in definitions(product):
        instructions.append(method+" "+path)
        if body: instructions.append(pretty(body))
        instructions.append("")
    (folder/"elasticsearch.console").write_text("\n".join(instructions).rstrip()+"\n",encoding="utf-8")

def req(method,path,body=None):
    r=requests.request(method,ES+path,json=body,timeout=80)
    if not r.ok: raise ValueError(f"{method} {path} {r.status_code} {r.text[:2200]}")
    return r.json()

if __name__=="__main__":
    import sys
    for p in ["Runner","Mocker"]: render(p)
    if "install" in sys.argv:
        header=definitions("Runner")[:2]
        for m,path,body in header:req(m,path,body)
        # This Docker instance is isolated. Production installs preserve any existing final pipeline.
        req("PUT","/_template/qaas-usage-local",{"index_patterns":["qaas-20*"],"order":200,
            "settings":{"index.final_pipeline":PIPE},"mappings":{"properties":raw}})
        req("PUT","/qaas-20*/_mapping",{"properties":raw})
        req("PUT","/qaas-20*/_settings",{"index.final_pipeline":PIPE})
        for p in ["Runner","Mocker"]:
            for m,path,body in definitions(p)[2:]:
                exists = requests.head(ES+path).ok if path.startswith("/qaasusage-") else False
                if not exists: req(m,path,body)
        print("Installed both native transforms")
