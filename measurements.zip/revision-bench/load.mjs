import http from 'node:http';
import { performance } from 'node:perf_hooks';
import { createInterface } from 'node:readline';
const args=JSON.parse(process.argv[2]);
const agent=new http.Agent({keepAlive:true,maxSockets:args.concurrency,maxFreeSockets:args.concurrency});
const routes={hit:[['/ok',200]],mixed:[['/ok',200],['/missing',404],['/degraded',503],['/throw',500]],error:[['/throw',500]]};
let activePort=args.port;
const scenario=routes[args.scenario];
if(!scenario)throw new Error(args.scenario);
function one(path,code){
 return new Promise((resolve,reject)=>{
  const request=http.get({hostname:'127.0.0.1',port:activePort,path,agent},r=>{
    r.on('error',reject);r.on('end',()=>r.statusCode===code?resolve():reject(Error(path+' yielded '+r.statusCode)));r.resume();
  });request.on('error',reject);request.setTimeout(15000,()=>request.destroy(Error('Timed out on '+path)));
 });
}
async function run(limit,duration){
 let issued=0;const times=[];const counts={};const start=performance.now();
 await Promise.all(Array.from({length:args.concurrency},async()=>{
  while(duration?performance.now()-start<duration:issued<limit){
    const i=issued++;const [path,code]=scenario[i%scenario.length],mark=performance.now();
    await one(path,code);times.push(performance.now()-mark);counts[code]=(counts[code]||0)+1;
  }
 }));
 const ms=performance.now()-start;times.sort((a,b)=>a-b);
 const percentile=p=>times[Math.max(0,Math.ceil(p*times.length)-1)];
 return {count:issued,ms,rps:issued*1000/ms,p50_ms:percentile(.50),p95_ms:percentile(.95),p99_ms:percentile(.99),statuses:counts};
}
try {
 const cmds=createInterface({input:process.stdin,crlfDelay:Infinity});
 for await(const s of cmds){
  if(s==='quit')break;
  const input=JSON.parse(s);
  activePort=input.port;
  const output=await run(input.count,input.duration);
  console.log(JSON.stringify(output));
 }
}finally{agent.destroy();}
