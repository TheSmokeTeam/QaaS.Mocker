from common import *
from collections import Counter
from statistics import median
import random

def timed(side,relay,fixture,i):
    arm={'off':'false','on':'true'}[side]
    argv=['dotnet',str(assembly('Runner','head')),'execute',str(fixture),'--send-logs','--elastic-uri',relay.url]
    env={**os.environ,'QAAS_USAGE_ENABLED':arm}
    zero=time.perf_counter();receipts={};seen=Counter()
    with subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace') as p:
        for msg in p.stdout:
            key=None
            if 'Elasticsearch username/password' in msg:key='first_warning'
            if 'Starting runner with 5 execution builders' in msg:key='start_build'
            if ('Running Act execution with executionId' in msg or 'Running Run execution with executionId' in msg):
                seen['act' if 'Running Act ' in msg else 'run']+=1
                if 'first_execution' not in receipts:key='first_execution'
            if 'Finished running executions. Aggregated exit code' in msg:key='finished_executions'
            if 'Runner completed. ExitCode=0' in msg:key='finished_cli'
            if key and key not in receipts:receipts[key]=[time.perf_counter()-zero,cpu(p)]
        if p.wait()!=0:raise RuntimeError((i,side,argv))
        end=time.perf_counter();receipts['exit']=[end-zero,cpu(p)]
    assert seen=={'act':1,'run':4},seen
    assert len(receipts)==6,receipts
    wait_for_bulk(relay)
    ledger=relay.ledger.snapshot()
    append('batch-phase.jsonl',dict(side=side,round=i,markers=receipts,ledger=ledger,counter_origin=zero,files=metadata('Runner','head')))
    print(i,side,receipts,flush=True)
def run():
    # Use the exact same file, owner, content and path in all 16 processes. Each relay captures one process.
    path=named_fixture('short.qaas.yaml','FixedOwnerPhase')
    sequence=ROOT/'phase-identical-batch.yaml'
    sequence.write_text('Commands:\n  - Id: Prepare\n    Command: act '+path.as_posix()+' --no-env\n  - Id: FourCases\n    Command: run '+path.as_posix()+' --no-env --cases '+(PREVIOUS/'cases').as_posix()+'\n',encoding='utf8')
    orders=[('off','on')]*4+[('on','off')]*4
    random.Random(74845).shuffle(orders)
    for i,order in enumerate(orders,1):
        for side in order:
            with Relay(19379,0) as relay:timed(side,relay,sequence,i)
if __name__=='__main__':run()
