import argparse,secrets
from common import *

class Host:
    def __init__(self,arm,side,mode,stack,number):
        self.build=arm['build']; self.port=19867+number; self.relay=relay_for(stack,mode,19380+number)
        self.owner='Load'+secrets.token_hex(6);self.side=side;self.meta=metadata('Mocker',self.build)
        source='mocker-enabled.qaas.yaml' if arm.get('httpAggregation') else 'mocker.qaas.yaml'
        fixture=named_fixture(source,self.owner,http=self.port)
        self.command=base_command('Mocker',self.build,'run',fixture,mode,self.relay,[*arm.get('args',[]),*arm.get('MockerArgs',[])])
        self.begin=time.perf_counter()
        self.proc=subprocess.Popen(self.command,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
             cwd=ROOT,env={**os.environ,**arm.get('env',{}),**arm.get('MockerEnv',{})},creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        self.stop_mode=None
        stack.callback(self.stop)
        for _ in range(240):
            if self.proc.poll() is not None:raise RuntimeError(f'Mocker {side} exited: {self.proc.returncode}')
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{self.port}/ok',timeout=.7) as resp:
                    if resp.read()!=b'healthy':raise ValueError('Readiness response mismatch')
                break
            except OSError:time.sleep(.085)
        else:raise TimeoutError(f'Mocker {side} failed readiness')
        self.startup_s=time.perf_counter()-self.begin
    def stop(self):
        if self.stop_mode is not None:return
        self.before_stop=process_metrics(self.proc)
        t=time.perf_counter()
        if self.proc.poll() is None:
            try:
                self.proc.send_signal(signal.CTRL_BREAK_EVENT)
                self.proc.wait(timeout=5);self.stop_mode='ctrl-break'
            except (OSError,subprocess.TimeoutExpired):
                self.proc.kill();self.proc.wait();self.stop_mode='kill-after-timeout'
        else:self.stop_mode='already-stopped'
        self.stop_s=time.perf_counter()-t
    def traffic(self):return self.relay.ledger.snapshot() if self.relay else None

def measure(args,mode,scenario):
    config=json.loads((ROOT/args.arms).read_text(encoding='utf-8-sig'))
    with ExitStack() as stack:
        order=('on','off') if args.swap else ('off','on')
        hosts={side:Host(config[side],side,mode,stack,i) for i,side in enumerate(order)}
        n=subprocess.Popen(['node',str(ROOT/'load.mjs'),json.dumps(dict(port=0,concurrency=args.concurrency,scenario=scenario))],
                           cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
        try:
            def ask(request):
                n.stdin.write(json.dumps(request)+'\n');n.stdin.flush()
                answer=n.stdout.readline()
                if not answer:raise RuntimeError('Load generator stopped unexpectedly')
                return json.loads(answer)
            total={side:0 for side in hosts}
            for side,h in hosts.items():total[side]=1+ask({'port':h.port,'count':args.warmup})['count']
            for i in range(args.start,args.start+args.rounds):
                for side in (('off','on') if i%2 else ('on','off')):
                    h=hosts[side]; pre=process_metrics(h.proc); before=h.traffic(); begin=now()
                    rows=ask({'port':h.port,'duration':args.seconds*1000})
                    after=process_metrics(h.proc); ledger=h.traffic();total[side]+=rows['count']
                    append(args.out,dict(begin=begin,end=now(),suite=args.label,case='http-'+scenario,mode=mode,round=i,side=side,
                           owner=h.owner,concurrency=args.concurrency,files=h.meta,command=h.command,cpu_s=after['cpu_s']-pre['cpu_s'],
                           cpu_us_per_req=(after['cpu_s']-pre['cpu_s'])*1e6/rows['count'],begin_memory=pre,end_memory=after,
                           peak_working_set_bytes=after['peak_working_set'],private_bytes=after['private'],ledger_before=before,
                           ledger=ledger,**rows))
                    print(mode,scenario,i,side,round(rows['rps']),round(rows['p95_ms'],3),flush=True)
            # Wait for the native 10s timer and the downstream sink to make completed observations visible.
            # Follows the last timed request; CLIs, not this reset, measure exit latency.
            time.sleep(args.settle)
            for side,h in hosts.items():
                h.stop();wait_for_bulk(h.relay)
                assert_suppressed(config[side],h.traffic())
                append('http-delivery.jsonl',dict(suite=args.label,case='http-'+scenario,mode=mode,side=side,owner=h.owner,
                      sent_including_readiness_and_warmup=total[side],ledger=h.traffic(),files=h.meta,stop=h.stop_mode,stop_s=h.stop_s,
                      startup_s=h.startup_s,peak_working_set_bytes=h.before_stop['peak_working_set']))
        finally:
            if n.poll() is None:
                try:n.stdin.write('quit\n');n.stdin.flush();n.wait(timeout=2)
                except (OSError,subprocess.TimeoutExpired):n.kill();n.wait()
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--label',required=True);p.add_argument('--arms',required=True);p.add_argument('--out',required=True)
    p.add_argument('--modes',default='disabled,healthy,slow,unreachable');p.add_argument('--scenarios',default='hit,mixed')
    p.add_argument('--swap',action='store_true',help='Reverse host startup order and serving ports for an independent replication.')
    p.add_argument('--rounds',type=int,default=4);p.add_argument('--start',type=int,default=1);p.add_argument('--seconds',type=float,default=3)
    p.add_argument('--concurrency',type=int,default=16);p.add_argument('--warmup',type=int,default=2500);p.add_argument('--settle',type=float,default=12)
    args=p.parse_args()
    for mode in args.modes.split(','):
        for scenario in args.scenarios.split(','):measure(args,mode,scenario)
