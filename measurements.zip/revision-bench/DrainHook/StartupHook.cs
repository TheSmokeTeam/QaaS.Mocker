using System.Diagnostics;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Text.Json;

public static class StartupHook
{
    public static void Initialize()
    {
        var output=Environment.GetEnvironmentVariable("QAAS_DRAIN_OBSERVATION");
        if(string.IsNullOrWhiteSpace(output))return;
        var program=Assembly.Load("QaaS.Mocker");
        Assembly.Load("QaaS.Mocker.Example");
        var factory=program.GetType("QaaS.Mocker.Bootstrap")!.GetMethods().Single(x=>x.Name=="New" && !x.IsGenericMethod);
        var runner=factory.Invoke(null,new object[]{Environment.GetCommandLineArgs().Skip(1).ToArray()})!;
        var type=runner.GetType();
        var property=type.GetProperty("DrainCliLogger", BindingFlags.Instance|BindingFlags.NonPublic);
        var original=(Action?)property?.GetValue(runner);
        using var process=Process.GetCurrentProcess();
        long WorkingSet(){process.Refresh();return process.WorkingSet64;}
        var bootstrapBytes=WorkingSet();
        var beforeBytes=0L;var afterBytes=0L;
        void Record(bool invoked,double elapsed)
        {
            // Write only primitive metrics; the diagnostic hook must not preload a JSON serializer.
            var text=System.FormattableString.Invariant($"{{\"attached\":{(original!=null?"true":"false")},\"invoked\":{(invoked?"true":"false")},\"elapsed_ms\":{elapsed:F6},\"bootstrap_ws_bytes\":{bootstrapBytes},\"before_ws_bytes\":{beforeBytes},\"after_ws_bytes\":{afterBytes}}}");
            File.WriteAllText(output,text);
        }
        Record(false,0);
        if (original!=null)
            property!.SetValue(runner,(Action)(()=>{
                beforeBytes=WorkingSet();var t=Stopwatch.GetTimestamp();
                try {original();}
                finally{var ms=Stopwatch.GetElapsedTime(t).TotalMilliseconds;afterBytes=WorkingSet();Record(true,ms);}
            }));
        try{type.GetMethod("Run")!.Invoke(runner,null);}
        catch(TargetInvocationException e) when(e.InnerException !=null){ExceptionDispatchInfo.Capture(e.InnerException).Throw();}
        Environment.Exit(0);
    }
}
