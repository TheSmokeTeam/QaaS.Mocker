from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from http.client import HTTPConnection
from threading import Thread,Lock
from common import *
from http_matrix import Host
from cli_matrix import timed
import argparse,secrets

class Confirm(BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def do_GET(self):
        upstream=HTTPConnection('127.0.0.1',self.server.destination,timeout=5)
        try:
            upstream.request('GET',self.path); response=upstream.getresponse();body=response.read()
            with self.server.lock:self.server.calls.append((self.path,response.status,body.decode('utf8',errors='replace')))
            self.send_response(response.status);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        finally:upstream.close()
class Gateway(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,port):
        super().__init__(('127.0.0.1',0),Confirm);self.lock=Lock();self.calls=[];self.destination=port
        self.thread=Thread(target=self.serve_forever,kwargs={'poll_interval':.04},daemon=True)
    def __enter__(self):self.thread.start();return self
    def __exit__(self,*_):self.shutdown();self.server_close();self.thread.join(2)
def fixture(port,owner,n):
    regression=ROOT.parent/'Runner/QaaS.Runner.Tests/TestData/http-get-empty-request.qaas.yaml'
    text=regression.read_text(encoding='utf8').replace('Team: investigation','Team: '+owner+'\n  ExtraLabels:\n    Project: Performance').replace('System: runner','System: CrossBench')
    text=text.replace('TimeoutMs: 100','TimeoutMs: 5000').replace('Port: 1','Port: '+str(port)).replace('Route: /','Route: /ok')
    assertion='  - Name: Verify{index:04d}\n    Assertion: {kind}\n    SessionNames: [empty-http-get]\n'
    text+='\nAssertions:\n'+''.join(assertion.format(index=i,kind='RabbitRoundTripAssertion' if i%32==0 else 'RabbitExhaustiveCombinationsAssertion') for i in range(n))
    path=ROOT/(owner+'.yaml');path.write_text(text,encoding='utf8');return path
def run(args):
    config=json.loads((ROOT/args.arms).read_text(encoding='utf-8-sig'))
    for mode in args.modes.split(','):
        with ExitStack() as stack:
            hosts={k:Host(a,k,mode,stack,i) for i,(k,a) in enumerate(config.items())}
            gateways={s:stack.enter_context(Gateway(h.port)) for s,h in hosts.items()}
            for i in range(1,args.rounds+1):
                for side in (('off','on') if i%2 else ('on','off')):
                    h=hosts[side];g=gateways[side];arm=config[side]
                    with ExitStack() as one:
                        relay=relay_for(one,mode,19379)
                        owner='Cross'+secrets.token_hex(6);path=fixture(g.server_port,owner,args.assertions);log=ROOT/'logs'/(owner+'.log');log.parent.mkdir(exist_ok=True)
                        cmd=base_command('Runner',arm['build'],'run',path,mode,relay,[*arm.get('args',[]),*arm.get('RunnerArgs',[])])
                        before=len(g.calls);start=now();server_before=process_metrics(h.proc)
                        val=timed(cmd,{**os.environ,**arm.get('env',{}),**arm.get('RunnerEnv',{})},1,log)
                        server_after=process_metrics(h.proc);wait_for_bulk(relay)
                        requests=g.calls[before:];assert requests==[('/ok',200,'healthy')],(log,requests)
                        logs=log.read_text(encoding='utf8',errors='replace')
                        seen=sum(f'Verify{x:04d}' in logs for x in range(args.assertions))
                        if seen!=args.assertions:raise ValueError(f'Found {seen}/{args.assertions} assertion names: {log}')
                        assert_suppressed(arm,relay.ledger.snapshot() if relay else None)
                        runner_terminal(relay.ledger.snapshot() if relay else None,seen)
                        row=dict(suite=args.label,case='runner-to-mocker-assertions',mode=mode,side=side,round=i,owner=owner,
                                 files=metadata('Runner',arm['build']),mocker_files=h.meta,begin=start,end=now(),
                                 requests_observed=requests,assertions_observed=seen,assertions_per_s=seen/val['wall_s'],
                                 expected_failed_assertions=(args.assertions+31)//32,server_before=server_before,server_after=server_after,
                                 ledger=relay.ledger.snapshot() if relay else None,**val)
                        append(args.out,row);print(mode,i,side,requests,seen,round(val['wall_s'],3),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--arms',default='candidate-usage.json');p.add_argument('--label',default='candidate-usage')
    p.add_argument('--out',default='cross.jsonl');p.add_argument('--rounds',type=int,default=3)
    p.add_argument('--modes',default='disabled,healthy,slow,unreachable');p.add_argument('--assertions',type=int,default=128)
    run(p.parse_args())
