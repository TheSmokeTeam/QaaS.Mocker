from pathlib import Path
import ctypes, subprocess, os, sys, time, json, signal, urllib.request, datetime, hashlib, platform, statistics, math
from ctypes import wintypes as wt
D=Path(__file__).resolve().parent
ES='http://127.0.0.1:19278'
MODES={'off':['--disable-elastic-defaults'],'debug':['--disable-elastic-defaults','--logger-level','Debug'],'console-config':['--disable-elastic-defaults','--logger-configuration-file',str(D/'console-debug.yaml')],'healthy':['--send-logs','--elastic-uri',ES],'unreachable':['--send-logs','--elastic-uri','http://127.0.0.1:19996']}
def assembly(repo,build):
    host='QaaS.Runner.E2ETests' if repo=='Runner' else 'QaaS.Mocker.Example'
    return D.parent/(repo+('Base' if build=='base' else ''))/host/'bin'/'Release'/'net10.0'/(host+'.dll')
def cpu(p):
    values=[wt.FILETIME() for i in range(4)]
    if not ctypes.windll.kernel32.GetProcessTimes(wt.HANDLE(int(p._handle)),*[ctypes.byref(v) for v in values]): raise ctypes.WinError()
    return sum((f.dwHighDateTime<<32|f.dwLowDateTime) for f in values[2:])/10_000_000
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def cmd(repo,build,operation,fixture,mode,flags=()):
    return ['dotnet',str(assembly(repo,build)),operation,str(D/fixture),'--no-env',*MODES[mode],*flags]
def invoke(args,cwd,expected):
    start=time.perf_counter()
    with subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,cwd=cwd) as proc:
        try: result=proc.wait(75)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait(); raise
        elapsed=time.perf_counter()-start
        if expected=='fail' and result==0 or isinstance(expected,int) and result!=expected:
            raise ValueError(f'{args}: expected {expected}, got {result}')
        return dict(wall_s=elapsed,cpu_s=cpu(proc),exit=result)
def http(build,mode,scale,enabled=True):
    # Enable/configure only the candidate's PR feature; both hosts share identical functional settings.
    fixture='mocker-enabled.qaas.yaml' if enabled and build=='head' else 'mocker.qaas.yaml'
    args=cmd('Mocker',build,'run',fixture,mode)
    with subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,cwd=D,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP) as host:
        try:
            for tries in range(160):
                if host.poll() is not None: raise RuntimeError(f'Mocker exited {host.returncode}')
                try:
                    with urllib.request.urlopen('http://127.0.0.1:19847/ok',timeout=.5) as res:
                        if res.read() != b'healthy': raise RuntimeError('Unexpected /ok response')
                    break
                except OSError: time.sleep(.10)
            else:raise TimeoutError('Waiting for Mocker')
            start_cpu=cpu(host)
            client=subprocess.run(['node',str(D/'load.mjs'),'19847',str(scale)],capture_output=True,text=True,timeout=280)
            if client.returncode: raise RuntimeError(client.stderr)
            measurements=[json.loads(line) for line in client.stdout.splitlines()]
            return measurements,cpu(host)-start_cpu
        finally:
            if host.poll() is None:
                try: host.send_signal(signal.CTRL_BREAK_EVENT);host.wait(timeout=4)
                except (OSError,subprocess.TimeoutExpired): host.kill();host.wait(timeout=4)
workloads=[
 ('runner-short','Runner','run','short.qaas.yaml',[],0),
 ('runner-busy-24-sessions','Runner','run','busy.qaas.yaml',[],0),
 ('runner-assertion-failure','Runner','run','failed.qaas.yaml',[],1),
 ('runner-cases-4','Runner','run','short.qaas.yaml',['--cases',str(D/'cases')],0),
 ('runner-act','Runner','act','short.qaas.yaml',[],0),
 ('runner-assert','Runner','assert','short.qaas.yaml',[],0),
 ('runner-template','Runner','template','short.qaas.yaml',[],0),
 ('runner-storage-failure','Runner','act','broken-storage.qaas.yaml',[],'fail'),
 ('runner-invalid-config','Runner','run','malformed.qaas.yaml',[],'fail'),
 ('runner-missing-metadata','Runner','run','unowned.qaas.yaml',[],1),
 ('mocker-short','Mocker','run','mocker.qaas.yaml',['--run-locally'],0),
 ('mocker-startup-failure','Mocker','run','mocker-failure.qaas.yaml',[],'fail'),
 ('mocker-template','Mocker','template','mocker.qaas.yaml',[],0),
 ('mocker-unowned','Mocker','run','mocker-unowned.qaas.yaml',['--run-locally'],0),
 ('mocker-prebuild-rejection','Mocker','run','mocker-rejected.qaas.yaml',[],'fail'),
]
def binaries(repo,build):
    directory=assembly(repo,build).parent
    names=['QaaS.Runner.dll'] if repo=='Runner' else ['QaaS.Mocker.dll','QaaS.Mocker.Servers.dll']
    return {name:hashlib.sha256((directory/name).read_bytes()).hexdigest() for name in names}
def record(path,obj):
    with path.open('a',encoding='utf-8') as fp:fp.write(json.dumps(obj,sort_keys=True)+'\n')
def main():
 import argparse
 parser=argparse.ArgumentParser()
 parser.add_argument('--phase',choices=['runner','mocker','http','http-optout','warm','calibrate'],required=True)
 parser.add_argument('--rounds',type=int,default=3)
 parser.add_argument('--modes',default='off,healthy,unreachable')
 parser.add_argument('--scale',type=float,default=1)
 parser.add_argument('--start',type=int,default=1)
 parser.add_argument('--output',default='measurements.jsonl')
 parser.add_argument('--fixtures',default='')
 parser.add_argument('--samples',type=int,default=20)
 args=parser.parse_args()
 output=D/args.output
 already={(r['round'],r['build'],r['mode'],r['name']) for r in map(json.loads,output.read_text().splitlines())} if output.exists() else set()
 modes=args.modes.split(',')
 if args.phase=='calibrate':
    print(http('base',modes[0],args.scale),flush=True)
    for name,repo,op,fixture,flags,expected in workloads:
        print(name,invoke(cmd(repo,'base',op,fixture,modes[0],flags),D,expected),flush=True)
    return
 labels=['base','head']
 for round in range(args.start,args.start+args.rounds):
    for mode_number,mode in enumerate(modes):
      if mode=='healthy':
        with urllib.request.urlopen(ES,timeout=5) as es: assert es.status==200
      order=labels if (round+mode_number)%2 else list(reversed(labels))
      if args.phase in ('http','http-optout'):
        for build in order:
           series,total_cpu=http(build,mode,args.scale,enabled=args.phase=='http')
           for value in series:
             if args.phase=='http-optout': value['name']+='-optout'
             record(output,dict(stamp=stamp(),round=round,build=build,binaries=binaries('Mocker',build),mode=mode,**value,server_batch_cpu_s=total_cpu))
           print(round,mode,build,'HTTP complete',flush=True)
      else:
        for name,repo,op,fixture,flags,expected in workloads:
           if args.phase=='warm' and not (repo=='Runner' and expected in (0,1)):continue
           if args.phase!='warm' and not name.startswith(args.phase) or args.fixtures and name not in args.fixtures.split(','):continue
           label=('warm-'+name if args.phase=='warm' else name)
           if all((round,build,mode,label) in already for build in order): continue
           while (D/'hold').exists():
             (D/'pair-idle').touch()
             time.sleep(.5)
           (D/'pair-idle').unlink(missing_ok=True)
           for build in order:
             if (round,build,mode,label) in already: continue
             if args.phase=='warm':
                result=D/'warm-result.json'
                result.unlink(missing_ok=True)
                env={**os.environ,'DOTNET_STARTUP_HOOKS':str(D/'WarmHook/bin/Release/net10.0/WarmHook.dll'),'QAAS_LOCAL_BENCH_EXPECT':str(expected),'QAAS_LOCAL_BENCH_COUNT':str(args.samples),'QAAS_LOCAL_BENCH_OUT':str(result)}
                subprocess.run(cmd(repo,build,op,fixture,mode,flags),cwd=D,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=180,check=True)
                value=json.loads(result.read_text())
             else: value=invoke(cmd(repo,build,op,fixture,mode,flags),D,expected)
             record(output,dict(stamp=stamp(),round=round,build=build,binaries=binaries(repo,build),mode=mode,name=('warm-'+name if args.phase=='warm' else name),**value))
           print(round,mode,name,'complete',flush=True)
if __name__=='__main__': main()


