"""Build matched local Mocker hosts for the native Elasticsearch transport comparison."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess


root = Path(__file__).resolve().parent
source = root / 'source'
project = 'QaaS.Framework.Executions/QaaS.Framework.Executions.csproj'
framework_dll = 'QaaS.Framework.Executions.dll'
source_commit = '97d599d3ad371cc413823c21b394847ffa8c8a87'
host = root.parent / 'Mocker' / 'QaaS.Mocker.Example' / 'bin' / 'Release' / 'net10.0'
artifact = source / 'QaaS.Framework.Executions' / 'bin' / 'Release' / 'net10.0' / framework_dll
expected = {
    framework_dll: '32274B5D1E6DD2ECD39B2825012827A5FF52F8D32AF217226954BECE59FC10AE',
    'QaaS.Mocker.Example.dll': '14AB83F303435A75E489A5C8C86406A12058DAA46BFB7611390528D3FB3C13F2',
    'QaaS.Mocker.dll': '3CDDE8390A828D1C66486DEB90F8C0D3F0CDC8D3D1575454E240470D1117642F',
    'QaaS.Mocker.Servers.dll': '4673F0E3AB08AB80EEF4A714668F623C66E9984DA5E9D0B968EB2F691F631928',
}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest().upper()


def run(command, log):
    print(' '.join(command), flush=True)
    with (root / log).open('wb') as stream:
        subprocess.run(command, cwd=source, stdout=stream, stderr=subprocess.STDOUT, check=True)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=source, text=True).strip()


assert git('rev-parse', 'HEAD') == source_commit and not git('status', '--short')
assert {name: sha(host / name) for name in expected} == expected
run(['dotnet', 'restore', project, '--disable-parallel', '-p:NuGetAudit=false', '-m:1'], 'restore.log')
build = ['dotnet', 'build', project, '-c', 'Release', '--no-restore', '-m:1', '-p:UseSharedCompilation=false', '--disable-build-servers']
receipt = {'sourceCommit': source_commit, 'packageVersion': '1.7.0', 'environment': {'sdk': subprocess.check_output(['dotnet','--version'], text=True).strip()}, 'build': build, 'productHost': expected, 'arms': {}}
for index, name in enumerate(['client-debug-stock', 'client-debug-omitted']):
    if index:
        git('apply', str(root / 'omit-client-debug.patch'))
        assert git('diff', '--name-only') == 'QaaS.Framework.Executions/ExecutionLogging.cs'
    run(build, name + '-build.log')
    output = root / name
    if output.exists():
        raise FileExistsError(output)
    shutil.copytree(host, output, ignore=lambda path, names: [framework_dll] if Path(path) == host else [])
    shutil.copyfile(artifact, output / framework_dll)
    digests = {key: sha(output / key) for key in expected}
    assert all(digests[key] == expected[key] for key in expected if key != framework_dll)
    receipt['arms'][name] = {'digests': digests, 'entry': str((output / 'QaaS.Mocker.Example.dll').resolve()), 'launch': ['dotnet', str(output / 'QaaS.Mocker.Example.dll')]}
    print(name, digests[framework_dll], flush=True)
assert receipt['arms']['client-debug-stock']['digests'][framework_dll] != receipt['arms']['client-debug-omitted']['digests'][framework_dll]
assert {name: sha(host / name) for name in expected} == expected
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
