from pathlib import Path
root=Path(__file__).resolve().parent
bench=root/'bench'
rev=root/'revision-bench'
fixture=rev/'FixedOwnerPhase.yaml'
fixture.write_text((bench/'short.qaas.yaml').read_text().replace('Team: PerfLab','Team: FixedOwnerPhase\n  ExtraLabels:\n    Project: Performance'))
(rev/'phase-identical-batch.yaml').write_text('Commands:\n  - Id: Prepare\n    Command: act '+fixture.as_posix()+' --no-env\n  - Id: FourCases\n    Command: run '+fixture.as_posix()+' --no-env --cases '+(bench/'cases').as_posix()+'\n')
bad=bench/'mocker-failure.qaas.yaml'
bad.write_text(bad.read_text().replace('C:/temp/qaas-pr78-45/bench/short.qaas.yaml',(bench/'short.qaas.yaml').as_posix()))
cert=root/'dashboard-validation/mocker-fail.yaml'
if cert.exists(): cert.write_text(cert.read_text().replace('C:/temp/qaas-pr78-45/dashboard-validation/good.yaml',(cert.parent/'good.yaml').as_posix()))
