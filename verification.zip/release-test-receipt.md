# Local Release test receipt

The final Runner source was `5a7fea36db809f3c0ee0910a8ef146a4c5a7f7d8`. Mocker runtime source was `e0206c292438b85aadd10f5339db55bc64d50ee4`. Its final PR head `707d875037018b080a38074208e4e1c562e7685a` adjusts the Grafana dashboard only. The final integration receipt has the hashes of the actual runtime and CLI assemblies. The tests and the CLI workloads used the same Release build outputs.

Run from the appropriate repository root with restored dependencies and .NET SDK 10.0.203.

```powershell
$env:DOTNET_CLI_USE_MSBUILD_SERVER='0'
dotnet build QaaS.Runner.sln -c Release --no-restore -m:1 -p:UseSharedCompilation=false
dotnet test QaaS.Runner.sln -c Release --no-restore --no-build -m:1
```

```powershell
$env:DOTNET_CLI_USE_MSBUILD_SERVER='0'
dotnet build QaaS.Mocker.sln -c Release --no-restore -m:1 -p:UseSharedCompilation=false
dotnet test QaaS.Mocker.sln --no-build --no-restore -m:1 -c Release
```

| Test assembly | Passed | Failed | Skipped |
|---|---:|---:|---:|
| QaaS.Runner.Assertions.Tests | 159 | 0 | 0 |
| QaaS.Runner.Infrastructure.Tests | 59 | 0 | 0 |
| QaaS.Runner.Storage.Tests | 40 | 0 | 0 |
| QaaS.Runner.Tests | 282 | 0 | 0 |
| QaaS.Runner.Sessions.Tests | 570 | 0 | 0 |
| QaaS.Mocker.Tests | 168 | 0 | 0 |
| QaaS.Mocker.Servers.Tests | 250 | 0 | 0 |
| QaaS.Mocker.Stubs.Tests | 28 | 0 | 0 |
| QaaS.Mocker.Controller.Tests | 39 | 0 | 0 |

Runner passed 1,110 tests. Mocker passed 485. During the first full Runner test under concurrent host load, `Command_WithDiscoveryResponsesArrivingWithinRequestWindow_DiscoversAndCommandsAllInstances` missed one of two simulated instances in a 120 ms discovery window. The full isolated rerun above passed on the same binary. The two-CLI integration workload is described in the separate functional reproduction kit.
